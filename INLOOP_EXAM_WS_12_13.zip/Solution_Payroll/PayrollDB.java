import java.util.List;
interface PayrollDB {
    abstract public List<Employee> getEmployeeList();
}