public class Functions {
    public static int factorial(int n) {
        // TODO: insert your implementation here
    }
}