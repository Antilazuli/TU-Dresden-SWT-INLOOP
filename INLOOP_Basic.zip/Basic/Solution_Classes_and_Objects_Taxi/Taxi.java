public class Taxi {
    private Human driver;
    private Human[] passengers = new Human[4]; 
    private int occupation = 0;
    public Taxi(Human driver) {
        this.driver = driver;
    }
    public String getDriverName() {
        return driver.toString();
    }
    public void add(Human passenger) {
        if(occupation <= 3) {
            this.passengers[occupation] = passenger;
            this.occupation += 1;
            System.out.println(passenger.toString()+" gets in.");
        }
        else {
            System.out.println("We are sorry, "+passenger.toString()+". The taxi is full.");
        }
    }
    public String toString() {
        String output = new String("This is the taxi of "+driver.toString()+". He takes ");
        if(occupation == 0) {
            output += "nobody ";
        }
        else if(occupation == 1) {
            output += passengers[0].toString()+" ";
        }
        else if(occupation >= 2) {
            output += passengers[0].toString();
            for(int i = 1; i < occupation - 1; i++) {
                output += ", "+passengers[i].toString();
            }
            output += " and "+passengers[occupation - 1].toString()+" ";
        }
        return output+"along.";
    }
    public Human[] allGetOut() {
        Human[] output = new Human[occupation];
        for(int i = 0; i < occupation; i++) {
            if(passengers[i] != null) {
                output[i] = passengers[i];
            }
        }
        this.passengers = new Human[4];
        this.occupation = 0;
        return output;
    }
}