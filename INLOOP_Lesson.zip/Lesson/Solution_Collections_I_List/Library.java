package collections1;
import java.util.*;
class Library {
    private List<Book> stock;
    public Library() {
         stock = new LinkedList<>();
    }
    public boolean insertBook(Book newBook) {
        stock.add(newBook);
        Collections.sort(stock);
        return true;
    }
    public Book searchForIsbn(String isbn) {
        if(stock.size() > 0 && Collections.binarySearch(stock, new Book(isbn)) >= 0) {
            return stock.get(Collections.binarySearch(stock, new Book(isbn)));
        }
        return null;
    }
    public Collection<Book> searchForAuthor(String author) {
         List<Book> booksOfAuthor = new ArrayList<Book>();
         for(Book currentlySearchedBook: stock) {
             if(currentlySearchedBook.getAuthor().equals(author)) {
                 booksOfAuthor.add(currentlySearchedBook);
             }
         }
         return booksOfAuthor;
    }
}