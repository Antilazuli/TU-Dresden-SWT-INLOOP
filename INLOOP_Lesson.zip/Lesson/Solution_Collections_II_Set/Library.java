package collections2;
import java.util.*;
class Library {
    private Set<Book> stock;
    public Library() {  
        stock = new TreeSet<>();
    }
    public boolean insertBook(Book book) {
        if (stock.contains(book)) {
            return false;
        }
        else {
            stock.add(book);
            return true;
        }
    }
    public Book searchForIsbn(String isbn) {
        for (Iterator<Book> it = stock.iterator(); it.hasNext();) {
            Book f = it.next();
            if (f.getIsbn().equals(isbn)) {
                return f;
            }
        }
        return null;
    }
    public Collection<Book> searchForAuthor(String author) {
         List<Book> booksOfAuthor = new ArrayList<Book>();
         for(Book currentlySearchedBook: stock) {
             if(currentlySearchedBook.getAuthor().equals(author)) {
                 booksOfAuthor.add(currentlySearchedBook);
             }
         }
         return booksOfAuthor;
    }
    public Collection<Book> getStock() {
        return stock;
    }
}