public abstract class Drink {
    
}