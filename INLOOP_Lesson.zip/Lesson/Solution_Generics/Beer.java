public class Beer extends Drink {
    protected String brewery;
    public Beer(String brewery) {
        this.brewery = brewery;
    }
    public String getBrewery() {
        return brewery;
    }
    public String toString() {
       return null; 
    }
}