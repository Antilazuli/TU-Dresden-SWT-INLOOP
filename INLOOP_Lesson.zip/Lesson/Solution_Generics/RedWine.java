public class RedWine extends Wine {
    private String region;
    public RedWine(String region) {
        super(region);
    }
}