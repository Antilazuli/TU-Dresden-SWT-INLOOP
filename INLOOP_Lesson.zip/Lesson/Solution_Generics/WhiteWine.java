public class WhiteWine extends Wine {
    public WhiteWine(String region) {
        super(region);
    }
}