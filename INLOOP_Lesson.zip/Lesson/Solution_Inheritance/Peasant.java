public class Peasant extends Inhabitant {
    
}