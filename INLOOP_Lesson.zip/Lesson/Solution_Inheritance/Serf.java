public class Serf extends Peasant {
    public int taxableIncome() {
        if((income - 12) > 0) {
            return income - 12;
        }
        else {
            return 0;
        }
    }
}