public class King extends Inhabitant {
    public int taxableIncome() {
        return 0;
    }
    public int tax() {
        return 0;
    }
}