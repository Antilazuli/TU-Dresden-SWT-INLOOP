public class Library {
    private Book[] content = new Book[10];
    private int occupation = 0;
    public Library() {
        System.out.println("Hello, I am a library, which can store up to 10 books!");
    }
    public void add(Book book) {
        if(occupation < 10) {
            occupation++;
            content[occupation-1] = book;
            System.out.println("I added the book "+book.toString()+"!");
        }
        else {
            System.out.println("The library is full!");
        }
    }
    public Book search(String title) {
        for(int i = 0; i < occupation; i++) {
            if(content[i].toString().equals(title)) {
                System.out.println("The book with the title "+title+" exists in the library!");
                return content[i];
            }
        }
        System.out.println("The book with the title "+title+" does not exist in the library!");
        return null;
    }
}