class Motor {
    public void upwards() {
        System.out.println("Motor is winding up");
    }
    public void downwards() {
        System.out.println("Motor is winding up");
    }
    public void stop() {
        System.out.println("Motor is stoped");
    }
}