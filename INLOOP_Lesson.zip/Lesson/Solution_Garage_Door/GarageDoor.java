import java.lang.*;
public class GarageDoor {
    private DoorState currentState = new Closed();
    private Motor myMotor = new Motor();

    abstract class DoorState {
       public void closeDoor() {}
       public void stopper() {}
       public void openDoor() {}
    }
    

    class Open extends DoorState {
        public void closeDoor() {
            myMotor.downwards();
            currentState = new Closing();
        }
    }

    class Closed extends DoorState {
        public void openDoor() {
            myMotor.upwards();
            currentState = new Opening();
        }
    }

    class Opening extends DoorState {
        public void stopper() {
            myMotor.stop();
            currentState = new Open();
        }

        public void closeDoor() {
            myMotor.downwards();
            currentState = new Closing();
        }
    }

    class Closing extends DoorState {
        public void stopper() {
            myMotor.stop();
            currentState = new Closed();
        }

        public void openDoor() {
            myMotor.upwards();
            currentState = new Opening();
        }
    }

    public void openDoor() throws IllegalStateException {
        if((currentState.getClass().getName() == "GarageDoor$Opening") || (currentState.getClass().getName() == "GarageDoor$Open")) {
            throw new IllegalStateException();
        }
        else {
            currentState.openDoor();
        }
    }

    public void closeDoor() throws IllegalStateException {
        System.out.println(currentState.getClass().getName());
        if((currentState.getClass().getName() == "GarageDoor$Closed") || (currentState.getClass().getName() == "GarageDoor$Closing")) {
            throw new IllegalStateException();
        }
        else {
            currentState.closeDoor();
        }
    }

    public void stopper() throws IllegalStateException {
        if((currentState.getClass().getName() == "GarageDoor$Closed") || (currentState.getClass().getName() == "GarageDoor$Open")) {
            throw new IllegalStateException();
        }
        else {
            currentState.stopper();
        }
    }
}
