package collections3;
import java.util.*;
class Library {
    private Map<String, Set<Book>> stock;
    public Library() {  
        stock = new TreeMap<>();
    }
    public boolean insertBook(Book newBook) {
        if(!stock.containsKey(newBook.getAuthor())) {
            Set<Book> value = new TreeSet<Book>();
            stock.put(newBook.getAuthor(), value);
        }
        if (stock.containsKey(newBook.getAuthor()) && stock.get(newBook.getAuthor()).contains(newBook)) {
            return false;
        }
        else {
            Set<Book> valueOfKey = stock.get(newBook.getAuthor());
            valueOfKey.add(newBook);
            stock.put(newBook.getAuthor(), valueOfKey);
            return true;
        }
    }
    public Book searchForIsbn(String isbn) {
        for (Map.Entry<String, Set<Book>> entry : stock.entrySet()) {
            Set<Book> valueOfKey = entry.getValue();
            for (Iterator<Book> i = valueOfKey.iterator(); i.hasNext();) {
                Book b = i.next();
                if (b.getIsbn().equals(isbn)) {
                    return b;
                }
            }
        }
        return null;
    }
    public Collection<Book> searchForAuthor(String author) {
        if (stock.containsKey(author)) {
            return stock.get(author);
        }
        return new TreeSet<Book>();
    }
    public Map<String, Set<Book>> listStockByAuthor() {
        return stock;
    }
    public Collection<Book> getStock() {
        List<Book> stockAsList = new ArrayList<Book>();
        for (Map.Entry<String, Set<Book>> entry : stock.entrySet()) {
            stockAsList.addAll(entry.getValue());
        }
        Collections.sort(stockAsList);
        return stockAsList;
    }
}